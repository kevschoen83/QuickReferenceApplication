package com.genspark.quickreferencerest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuickReferenceRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuickReferenceRestApplication.class, args);
	}

}
