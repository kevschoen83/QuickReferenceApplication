package com.genspark.quickreferencerest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuickReferenceRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
